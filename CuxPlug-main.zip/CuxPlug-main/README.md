[DMCA notice](https://github.com/ycngmn/CuxPlug/blob/main/DMCA-notice.md)

---
# CuxPlug
International plugins for [CloudStream](https://cloudstream.on.fleek.co) developed from fun and interest

---
## Installation
### [Automatic](https://self-similarity.github.io/http-protocol-redirector?r=cloudstreamrepo://raw.githubusercontent.com/ycngmn/CuxPlug/refs/heads/main/repo.json)
### Manual
- Navigate
    - Settings
    - extensions
    - add repository
- in repository URL, input either
    - short-code: `CuxPlug`
    - direct-link: `https://raw.githubusercontent.com/ycngmn/CuxPlug/refs/heads/main/repo.json`
---
## Extensions
- [**Watch32**](https://watch32.sx): Watch32 is a Free Movies streaming site with over 10000 movies and TV-Series.
- [**AniZone**](https://anizone.to): Anizone.to is a website with no about us section but hey, there are anime.
- [**AnimeSama**](https://anime-sama.fr): Anime-Sama est un site de référencement et de catalogage, créé par des passionnés de l’animation et du divertissement APAC.
- [**StreamCloud**](https://streamcloud.my): Stream Filme Kostenlos Online anschauen Deutsch.
- [**French-stream**](https://fstream.one): French Stream est un site qui va récupèrer les films et séries sur des plateformes comme Disney+, Netflix, Amazon Prime Video, HBO, Apple TV , Wakanim, Viki... et vous les proposer Gratuitement!
- ~~[**FreeDriveMovie**](https://freedrivemovie.com)~~: Indian multi-lingual movies & TV shows.
- [**Flixmet**](https://flixmet.com): Watch any movie worldwide including Hollywood, Bollywood and Bengali. PREFER DOWNLOAD THAN STREAMING!